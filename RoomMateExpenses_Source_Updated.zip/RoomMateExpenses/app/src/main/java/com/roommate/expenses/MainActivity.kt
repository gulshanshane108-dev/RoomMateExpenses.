package com.roommate.expenses

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.text.SimpleDateFormat
import java.util.*

data class Member(val uid: String = "", val name: String = "", val whatsapp: String = "", val role: String = "member")
data class Expense(val id: String = "", val memberUid: String = "", val memberName: String = "",
                   val item: String = "", val amount: Double = 0.0, val category: String = "Other",
                   val date: Long = System.currentTimeMillis())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { RoomMateApp() } }
    }
}

@Composable
fun RoomMateApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var uid by remember { mutableStateOf(auth.currentUser?.uid.orEmpty()) }
    var roomId by remember { mutableStateOf("") }
    var myName by remember { mutableStateOf("") }
    var whatsapp by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var roomName by remember { mutableStateOf("My Room") }
    var item by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var message by remember { mutableStateOf("Connecting…") }
    var expenses by remember { mutableStateOf(listOf<Expense>()) }
    var members by remember { mutableStateOf(listOf<Member>()) }
    var isAdmin by remember { mutableStateOf(false) }

    val db = remember { FirebaseDatabase.getInstance().reference }
    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            auth.signInAnonymously().addOnSuccessListener { uid = it.user?.uid.orEmpty(); message = "Ready" }
                .addOnFailureListener { message = "Firebase setup error: ${it.message}" }
        } else { uid = auth.currentUser?.uid.orEmpty(); message = "Ready" }
    }

    fun watchRoom(id: String) {
        roomId = id
        db.child("rooms").child(id).child("members").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                members = s.children.mapNotNull { it.getValue(Member::class.java) }
                isAdmin = s.child(uid).child("role").getValue(String::class.java) == "admin"
            }
            override fun onCancelled(e: DatabaseError) { message = e.message }
        })
        db.child("rooms").child(id).child("expenses").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                expenses = s.children.mapNotNull { it.getValue(Expense::class.java) }.sortedByDescending { it.date }
            }
            override fun onCancelled(e: DatabaseError) { message = e.message }
        })
    }

    fun createRoom() {
        if (uid.isBlank() || myName.isBlank() || whatsapp.isBlank()) { message = "Enter your name and WhatsApp number"; return }
        val code = (100000..999999).random().toString()
        val id = db.child("rooms").push().key ?: return
        val member = Member(uid, myName.trim(), whatsapp.trim(), "admin")
        val room = mapOf("name" to roomName, "createdBy" to uid, "createdAt" to ServerValue.TIMESTAMP)
        db.child("rooms").child(id).child("info").setValue(room).addOnSuccessListener {
            db.child("rooms").child(id).child("members").child(uid).setValue(member).addOnSuccessListener {
                db.child("inviteCodes").child(code).setValue(id).addOnSuccessListener {
                    invite = code; watchRoom(id); message = "Room created. Share code $code"
                }.addOnFailureListener { message = it.message ?: "Could not create invite code" }
            }
        }.addOnFailureListener { message = it.message ?: "Could not create room" }
    }

    fun joinRoom() {
        if (uid.isBlank() || myName.isBlank() || whatsapp.isBlank() || invite.length != 6) {
            message = "Enter name, WhatsApp number and 6-digit invite code"; return
        }
        db.child("inviteCodes").child(invite).get().addOnSuccessListener { snap ->
            val id = snap.getValue(String::class.java)
            if (id.isNullOrBlank()) { message = "Invalid invite code"; return@addOnSuccessListener }
            val member = Member(uid, myName.trim(), whatsapp.trim(), "member")
            db.child("rooms").child(id).child("members").child(uid).setValue(member).addOnSuccessListener {
                watchRoom(id); message = "Joined room successfully"
            }.addOnFailureListener { message = it.message ?: "Could not join room" }
        }.addOnFailureListener { message = it.message ?: "Could not look up invite code" }
    }

    fun addExpense() {
        val value = amount.toDoubleOrNull()
        if (roomId.isBlank() || item.isBlank() || value == null || value <= 0) { message = "Enter an item and a valid amount"; return }
        val ref = db.child("rooms").child(roomId).child("expenses").push()
        val expense = Expense(ref.key ?: "", uid, myName, item.trim(), value, category, System.currentTimeMillis())
        ref.setValue(expense).addOnSuccessListener { item = ""; amount = ""; message = "Expense added for everyone" }
            .addOnFailureListener { message = it.message ?: "Could not add expense" }
    }

    val monthExpenses = expenses.filter {
        val c = Calendar.getInstance(); c.timeInMillis = it.date
        val n = Calendar.getInstance()
        c.get(Calendar.YEAR) == n.get(Calendar.YEAR) && c.get(Calendar.MONTH) == n.get(Calendar.MONTH)
    }
    val total = monthExpenses.sumOf { it.amount }
    val money = { n: Double -> "₹" + String.format(Locale("en", "IN"), "%,.2f", n) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("RoomMate Expenses", style = MaterialTheme.typography.headlineMedium)
        Text(message, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        if (roomId.isBlank()) {
            OutlinedTextField(value = roomName, onValueChange = { roomName = it }, label = { Text("Room name (admin)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = myName, onValueChange = { myName = it }, label = { Text("Your name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = invite, onValueChange = { invite = it.filter(Char::isDigit).take(6) }, label = { Text("Room invite code (to join)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { createRoom() }, enabled = uid.isNotBlank()) { Text("Create room") }
                OutlinedButton(onClick = { joinRoom() }, enabled = uid.isNotBlank()) { Text("Join room") }
            }
        } else {
            Text("Room code: $invite", style = MaterialTheme.typography.titleMedium)
            Text("Monthly room expenses: ${money(total)}", style = MaterialTheme.typography.headlineSmall)
            Text("Members: ${members.size}   •   Entries this month: ${monthExpenses.size}")
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = item, onValueChange = { item = it }, label = { Text("What did you buy?") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount (₹)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { addExpense() }, modifier = Modifier.fillMaxWidth()) { Text("Add expense") }
            Spacer(Modifier.height(12.dp))
            Text("Expense history", style = MaterialTheme.typography.titleLarge)
            LazyColumn(Modifier.weight(1f)) {
                items(expenses) { e ->
                    val day = SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date(e.date))
                    ListItem(headlineContent = { Text(e.item + "  •  ${money(e.amount)}") },
                        supportingContent = { Text("${e.memberName} · $day · ${e.category}") })
                    HorizontalDivider()
                }
            }
            Text("Members: " + members.joinToString { it.name + if (it.role == "admin") " (admin)" else "" })
            if (isAdmin) Text("Admin controls and member removal will be expanded in the next build.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
