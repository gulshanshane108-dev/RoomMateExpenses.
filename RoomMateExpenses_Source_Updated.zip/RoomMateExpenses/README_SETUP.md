# RoomMate Expenses – Android starter project

## Included
- Native Android app using Kotlin + Jetpack Compose
- Firebase Realtime Database integration
- Silent anonymous Firebase Authentication (no login screen / password / OTP)
- Create room, join with 6-digit invite code, add expenses, shared live expense list
- Monthly total and member list
- INR display

## Important status
This is a starter implementation, not a verified release APK. It has not been compiled or tested on a physical Android device. Admin member-removal controls, date/month selection, per-member dashboard filtering, invite-code expiry/rotation, and production-grade invite-code abuse protection still need to be completed before public use.

## Firebase setup
1. Create a Firebase project at https://console.firebase.google.com/
2. Add an Android app with package name: `com.roommate.expenses`
3. Download `google-services.json` and put it in the `app/` directory.
4. In Firebase Authentication -> Sign-in method, enable **Anonymous**.
5. Create a Realtime Database.
6. Review `firebase-database.rules.json` and publish the rules.
7. Confirm the Realtime Database URL in Firebase project configuration if your database is not in the default region.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then:
- Build -> Build Bundle(s) / APK(s) -> Build APK(s)
- APK output: `app/build/outputs/apk/debug/app-debug.apk`

Or from a machine with Android SDK installed:
`gradle assembleDebug`

## Security / privacy notes
- No traditional user login is shown. Firebase anonymous auth assigns a UID to each installation.
- The current starter rules are a baseline and must be reviewed before real-world use. The invite-code lookup is readable to authenticated app instances. Use long random invite tokens and add server-side rate limiting / callable backend validation before wider distribution.
- WhatsApp numbers are personal data. Collect only with members' knowledge and restrict room access.
- Do not put service-account keys or admin credentials in the Android app.
- A room code is not a substitute for database security rules.

## Data structure
rooms/{roomId}/info
rooms/{roomId}/members/{uid}
rooms/{roomId}/expenses/{expenseId}
inviteCodes/{sixDigitCode}
